#!/usr/local/cwp/php71/bin/php -q
<?php

// CentOS WebPanel AutoResponder script v2

function remove_empty_line($replace){
    $replace = preg_replace('/\n/', '', $replace);
    return $replace;
}

# Settings
$postfix_password = shell_exec("grep '^password' /etc/postfix/mysql-virtual_vacation.cf| awk {'print $3'}");
$postfix_password = remove_empty_line($postfix_password);

$mysql_conn_postfix = mysqli_connect("localhost", "postfix", $postfix_password, "postfix");
$mysql_postfix = mysqli_select_db($mysql_conn_postfix, "postfix") or die("Could not connect to postfix database please check configuration!");


$recepient_split = preg_split ("/@/", $argv[2]);
$recepient_split2 = preg_split ("/#/", $recepient_split[0]);
$recepient = $recepient_split2[0]."@".$recepient_split2[1];


$ck1=mysqli_query($mysql_conn_postfix,"SHOW COLUMNS FROM vacation LIKE 'start_date' ");
if ($ck1->num_rows==0){
    $query="ALTER TABLE vacation ADD COLUMN start_date datetime NOT NULL";
    $sql = $mysql_conn_postfix->query($query);
}
$ck2=mysqli_query($mysql_conn_postfix,"SHOW COLUMNS FROM vacation LIKE 'end_date' ");
if ($ck2->num_rows==0){
    $query="ALTER TABLE vacation ADD COLUMN end_date datetime NOT NULL";
    $sql = $mysql_conn_postfix->query($query);
}
$ck2=mysqli_query($mysql_conn_postfix,"SHOW COLUMNS FROM vacation LIKE 'send_date_range' ");
if ($ck2->num_rows==0){
    $query="ALTER TABLE vacation ADD COLUMN send_date_range int NOT NULL";
    $sql = $mysql_conn_postfix->query($query);
}
$ck2=mysqli_query($mysql_conn_postfix,"SHOW COLUMNS FROM vacation LIKE 'interval' ");
if ($ck2->num_rows==0){
    $query="ALTER TABLE vacation ADD COLUMN `interval` varchar(60) NULL DEFAULT '*'";
    $sql = $mysql_conn_postfix->query($query);
}
$ck2=mysqli_query($mysql_conn_postfix,"SHOW COLUMNS FROM vacation LIKE 'fromname' ");
if ($ck2->num_rows==0){
    $query="ALTER TABLE vacation ADD COLUMN fromname varchar(60) NULL";
    $sql = $mysql_conn_postfix->query($query);
}
$ck2=mysqli_query($mysql_conn_postfix,"SHOW COLUMNS FROM vacation LIKE 'charset' ");
if ($ck2->num_rows==0){
    $query="ALTER TABLE vacation ADD COLUMN charset varchar(20) NULL DEFAULT 'iso-8859-1'";
    $sql = $mysql_conn_postfix->query($query);
}
$ck2=mysqli_query($mysql_conn_postfix,"SHOW COLUMNS FROM vacation LIKE 'username' ");
if ($ck2->num_rows==0){
    $query="ALTER TABLE vacation ADD COLUMN username varchar(15) NULL";
    $sql = $mysql_conn_postfix->query($query);
}
include "/etc/postfix/vacation_class.php";
$vacation = new VacationHandler($mysql_conn_postfix);
$vacation->processReply($recepient, $argv[1]);

?>