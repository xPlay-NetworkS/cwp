<?php
  // include PATH_PHPEDITOR_PATH . '/traits/general_trait.php';
  // include PATH_PHPEDITOR_PATH . '/traits/store_trait.php';
class VacationHandler{
  private $mysqli;
  private $recepient;
  private $tosend;
  private $reply;
  private $db_interval;
  public function __construct($mysqli){
    $this->mysqli = $mysqli;
    $this->db_interval = $mysqli;
  }
  public function processReply($recepient, $tosend){
    $this->recepient = $recepient;
    $this->tosend = $tosend;
    if($this->reply = $this->getReply($recepient)){
      if($this->replyAllowed()){
        $this->sendReply();
      }
    }
  }
  private function sendReply(){
    $subject = $this->reply->subject;
    $message = $this->reply->body;
    $headers = '';
    if(!empty($this->reply->fromname)){
      $headers = 'From: ' . $this->reply->fromname . ' <' . $this->recepient . '>' . "\r\n";
    }else{
      $headers = 'From: ' . $this->recepient . "\r\n";
    }
    $content_type = property_exists($this->reply,'ishtml') && $this->reply->ishtml == 1 ? 'text/html' : 'text/plain';
    $headers .= 'Content-type: ' . $content_type . '; charset=' . $this->reply->charset . "\r\n";
    $headers .= 'MIME-Version: 1.0' . "\r\n";
    $headers .= "Reply-To: " . $this->recepient . "\r\n" .
              "X-Mailer: PHP/" . phpversion();
    mail($this->tosend, $subject, $message, $headers);
  }
  private function storeLastReply($type){
    if($type == 'update'){
      $query = "UPDATE vacation_sent_replies SET last_sent = " . time() . " WHERE autoreply = '" . $this->recepient . "' AND reciever = '" . $this->tosend . "'";
    }else{
      $query = "INSERT INTO vacation_sent_replies (last_sent, autoreply, reciever) VALUES (" . time() . ",'" . $this->recepient . "','" . $this->tosend . "')";
    }
    // $this->db_interval->busyTimeout(5000);
    $this->db_interval->query($query);
    // $this->closeAdvDB();
  }
  private function replyAllowed(){
    if($this->reply->interval == '*'){
      return true;
    }else{
      // $start = new DateTime('2020-01-01 00:00:00');
      // echo $start->getTimestamp();
      // die;
      if($last_reply = $this->lastReply()){
        $nowtime = time();
        if($this->reply->interval == '1/*'){
          $beginOfDay = strtotime("today", $nowtime);
          if($beginOfDay < $last_reply->last_sent){
            // $this->closeAdvDB();
            return false;
          }
        }elseif($this->reply->interval == '1/1'){
          // $this->closeAdvDB();
          return false;
        }else{
          $next_allow  = $last_reply->last_sent + ($this->reply->interval * 3600);
          if($nowtime < $next_allow){
            // $this->closeAdvDB();
            return false;
          }
        }
        $this->storeLastReply('update');
        return true;
      }else{
        $this->storeLastReply('insert');
        return true;
      }
    }
  }
  private function lastReply(){
    $this->loadAdvDB();
    $sql = "SELECT * FROM vacation_sent_replies WHERE autoreply = '" . $this->recepient . "' AND reciever = '" . $this->tosend ."'";
    // $this->db_interval->busyTimeout(5000);
    $reply_exec = $this->db_interval->query($sql);
    if($reply_row = $reply_exec->fetch_object()){
      return $reply_row;
    }else{
      return false;
    }
  }
  private function closeAdvDB(){
    // $this->db_interval->close();
  }
  private function loadAdvDB(){
    // $file = '/home/' . $this->reply->username . '/.conf/.autoreplystats.sqlite';
    // $should_init = !file_exists($file) ? true : false;
    // $this->db_interval = new SQLite3($file, SQLITE3_OPEN_CREATE | SQLITE3_OPEN_READWRITE);
    // if($should_init){
    //   $this->db_interval->query('CREATE TABLE IF NOT EXISTS "vacation_sent_replies" (
    //     autoreply TEXT,
    //     reciever TEXT,
    //     last_sent INTEGER)');
    // }
      $this->db_interval->query('CREATE TABLE IF NOT EXISTS `vacation_sent_replies` (
        `autoreply` varchar(50) NOT NULL,
        `reciever` varchar(50) NOT NULL,
        `last_sent` bigint(0))');
  }
  private function getReply($recepient){
    $query = "SELECT * FROM vacation WHERE active='1' AND email='" . $this->recepient . "'";
    $reply_exec = $this->mysqli->query($query);
    if($reply = $reply_exec->fetch_object()){
      if($reply->send_date_range == 1){
        $start = new DateTime($reply->start_date);
        $end = new DateTime($reply->end_date);
        $today = new DateTime();
        if($today->getTimestamp() > $start->getTimestamp() && $today->getTimestamp() < $end->getTimestamp()){
          return $reply;
        }else{
          return false;
        }
      }else{
        return $reply;
      }
    }else{
      return false;
    }
  }
}
?>