<?php
if($_SERVER['REMOTE_ADDR']!='127.0.0.1'){die;}

/*if(!file_exists('/usr/bin/sqlite3')){
  shell_exec('yum -y install sqlite-devel');
}*/


$fp = fopen("/root/.my.cnf", "r");
while (!feof($fp)) {
    $linea = fgets($fp);
    if (strpos($linea, 'password=') !== false) {
        $pass = str_replace('password=', '', $linea);
    }
}
fclose($fp);
$bdname="oauthv2";
$dsn      = 'mysql:dbname='.$bdname.';host=localhost';
$username = 'root';
//$password = 'zlCqMYvq6iHW';
$password = trim($pass);
// error reporting (this is a demo, after all!)
//ini_set('display_errors',1);error_reporting(E_ALL);

$mysqli = new mysqli("localhost", "root", $password, $bdname);
if ($mysqli->connect_errno){
    $mysqli2 = new mysqli("localhost", "root", $password);
    $sql = "CREATE DATABASE `".$bdname."`  DEFAULT CHARSET=utf8;";
    if ($mysqli2->query($sql) === TRUE){
        $mysqli = new mysqli("localhost", "root", $password, $bdname);
        $sql1='CREATE TABLE `oauth_access_tokens` (
              `access_token` varchar(40) NOT NULL,
              `client_id` varchar(80) NOT NULL,
              `user_id` varchar(255) DEFAULT NULL,
              `expires` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              `scope` varchar(2000) DEFAULT NULL,
              PRIMARY KEY (`access_token`)
             )ENGINE=MyISAM DEFAULT CHARSET=utf8;';
        $sql2="CREATE TABLE `oauth_authorization_codes` (
              `authorization_code` varchar(40) NOT NULL,
              `client_id` varchar(80) NOT NULL,
              `user_id` varchar(255) DEFAULT NULL,
              `redirect_uri` varchar(2000) DEFAULT NULL,
              `expires` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              `scope` varchar(2000) DEFAULT NULL,
              PRIMARY KEY (`authorization_code`)
            )ENGINE=MyISAM DEFAULT CHARSET=utf8;";
        $sql3="CREATE TABLE `oauth_clients` (
              `client_id` varchar(80) NOT NULL,
              `client_secret` varchar(80) DEFAULT NULL,
              `redirect_uri` varchar(2000) NOT NULL,
              `grant_types` varchar(80) DEFAULT NULL,
              `scope` varchar(100) DEFAULT NULL,
              `user_id` varchar(80) DEFAULT NULL,
              PRIMARY KEY (`client_id`)
            )ENGINE=MyISAM DEFAULT CHARSET=utf8;";
        $sql4="CREATE TABLE `oauth_jwt` (
              `client_id` varchar(80) NOT NULL,
              `subject` varchar(80) DEFAULT NULL,
              `public_key` varchar(2000) DEFAULT NULL,
              PRIMARY KEY (`client_id`)
            );";

        $sql5="CREATE TABLE `oauth_refresh_tokens` (
          `refresh_token` varchar(40) NOT NULL,
          `client_id` varchar(80) NOT NULL,
          `user_id` varchar(255) DEFAULT NULL,
          `expires` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          `scope` varchar(2000) DEFAULT NULL,
          PRIMARY KEY (`refresh_token`)
        )ENGINE=MyISAM DEFAULT CHARSET=utf8;";
        $sql6="CREATE TABLE `oauth_scopes` (
          `scope` text,
          `is_default` tinyint(1) DEFAULT NULL
        );";
        $sql7="CREATE TABLE `oauth_users` (
          `username` varchar(255) NOT NULL,
          `password` varchar(2000) DEFAULT NULL,
          `first_name` varchar(255) DEFAULT NULL,
          `last_name` varchar(255) DEFAULT NULL,
          PRIMARY KEY (`username`)
        )ENGINE=MyISAM DEFAULT CHARSET=utf8;";

        $mysqli->query($sql1);
        $mysqli->query($sql2);
        $mysqli->query($sql3);
        $mysqli->query($sql4);
        $mysqli->query($sql5);
        $mysqli->query($sql6);
        $mysqli->query($sql7);
    }
    $tables=array('oauth_clients','oauth_authorization_codes','oauth_users','oauth_scopes','oauth_refresh_tokens','oauth_jwt','oauth_access_tokens');
    $falta=0;
    for($i=0;$i<count($tables);$i++){
        if ($result = $mysqli->query("SHOW TABLES LIKE '".$tables[$i]."'")) {
            if($result->num_rows == 0) {
                if($tables[$i]=='oauth_access_tokens'){
                    $sql='CREATE TABLE `oauth_access_tokens` (
                  `access_token` varchar(40) NOT NULL,
                  `client_id` varchar(80) NOT NULL,
                  `user_id` varchar(255) DEFAULT NULL,
                  `expires` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  `scope` varchar(2000) DEFAULT NULL,
                  PRIMARY KEY (`access_token`)
                 )ENGINE=MyISAM DEFAULT CHARSET=utf8;
                 ';
                    $mysqli->query($sql);
                    $falta++;
                }
                if($tables[$i]=='oauth_authorization_codes'){
                    $sql="CREATE TABLE `oauth_authorization_codes` (
                  `authorization_code` varchar(40) NOT NULL,
                  `client_id` varchar(80) NOT NULL,
                  `user_id` varchar(255) DEFAULT NULL,
                  `redirect_uri` varchar(2000) DEFAULT NULL,
                  `expires` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  `scope` varchar(2000) DEFAULT NULL,
                  PRIMARY KEY (`authorization_code`)
                )ENGINE=MyISAM DEFAULT CHARSET=utf8;";
                    $mysqli->query($sql);
                    $falta++;
                }
                if($tables[$i]=='oauth_clients'){
                    $sql="CREATE TABLE `oauth_clients` (
                  `client_id` varchar(80) NOT NULL,
                  `client_secret` varchar(80) DEFAULT NULL,
                  `redirect_uri` varchar(2000) NOT NULL,
                  `grant_types` varchar(80) DEFAULT NULL,
                  `scope` varchar(100) DEFAULT NULL,
                  `user_id` varchar(80) DEFAULT NULL,
                  PRIMARY KEY (`client_id`)
                )ENGINE=MyISAM DEFAULT CHARSET=utf8;";
                    $mysqli->query($sql);
                    $falta++;
                }
                if($tables[$i]=='oauth_jwt'){
                    $sql="CREATE TABLE `oauth_jwt` (
                  `client_id` varchar(80) NOT NULL,
                  `subject` varchar(80) DEFAULT NULL,
                  `public_key` varchar(2000) DEFAULT NULL,
                  PRIMARY KEY (`client_id`)
                )ENGINE=MyISAM DEFAULT CHARSET=utf8;";
                    $mysqli->query($sql);
                    $falta++;
                }
                if($tables[$i]=='oauth_refresh_tokens'){
                    $sql="CREATE TABLE `oauth_refresh_tokens` (
                  `refresh_token` varchar(40) NOT NULL,
                  `client_id` varchar(80) NOT NULL,
                  `user_id` varchar(255) DEFAULT NULL,
                  `expires` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  `scope` varchar(2000) DEFAULT NULL,
                  PRIMARY KEY (`refresh_token`)
                )ENGINE=MyISAM DEFAULT CHARSET=utf8;";
                    $mysqli->query($sql);
                    $falta++;
                }
                if($tables[$i]=='oauth_scopes'){
                    $sql="CREATE TABLE `oauth_scopes` (
                  `scope` text,
                  `is_default` tinyint(1) DEFAULT NULL
                )ENGINE=MyISAM DEFAULT CHARSET=utf8;";
                    $mysqli->query($sql);
                    $falta++;
                }
                if($tables[$i]=='oauth_users'){
                    $sql="CREATE TABLE `oauth_users` (
                  `username` varchar(255) NOT NULL,
                  `password` varchar(2000) DEFAULT NULL,
                  `first_name` varchar(255) DEFAULT NULL,
                  `last_name` varchar(255) DEFAULT NULL,
                  PRIMARY KEY (`username`)
                )ENGINE=MyISAM DEFAULT CHARSET=utf8;";
                    $mysqli->query($sql);
                    $falta++;
                }
            }
        }
    }
}

// Autoloading (composer is preferred, but for this example let's just do this)
require_once('/usr/local/cwpsrv/var/services/oauth/v2/server/OAuth2/Autoloader.php');

OAuth2\Autoloader::register();

// $dsn is the Data Source Name for your database, for exmaple "mysql:dbname=my_oauth2_db;host=localhost"
$storage = new OAuth2\Storage\Pdo(array('dsn' => $dsn, 'username' => $username, 'password' => $password));

// Pass a storage object or array of storage objects to the OAuth2 server class
$server = new OAuth2\Server($storage);

// Add the "Client Credentials" grant type (it is the simplest of the grant types)
$server->addGrantType(new OAuth2\GrantType\ClientCredentials($storage));

// Add the "Authorization Code" grant type (this is where the oauth magic happens)
$server->addGrantType(new OAuth2\GrantType\AuthorizationCode($storage));