#!/bin/bash
if [ -e "/opt/alt/php-fpm56/usr/bin/php-config" ];then
yum -y install memcached

cd /usr/local/src
rm -rf memcache-2.2.7
rm -rf memcache-2.2.7.tgz
wget http://static.cdn-cwp.com/files/php/pecl/memcache-2.2.7.tgz
tar -zxvf memcache-2.2.7.tgz
cd memcache-2.2.7
/opt/alt/php-fpm56/usr/bin/phpize
./configure --with-php-config=/opt/alt/php-fpm56/usr/bin/php-config
make
make install

systemctl restart memcached
systemctl enable memcached

PHPEXTDIR=`/opt/alt/php-fpm56/usr/bin/php-config --extension-dir`

if [ -e "$PHPEXTDIR/memcache.so" ];then 
	echo "Creating config file"
	grep "memcache.so" /opt/alt/php-fpm56/usr/php/php.d/memcache.ini 2> /dev/null 1> /dev/null|| echo "extension=memcache.so" > /opt/alt/php-fpm56/usr/php/php.d/memcache.ini
else
	echo "ERROR: Missing extension file $PHPEXTDIR/memcache.so"
fi
else
echo "Skipping as php build failed"
fi
