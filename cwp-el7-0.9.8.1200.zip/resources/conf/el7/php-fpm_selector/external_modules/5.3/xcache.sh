#!/bin/bash
if [ -e "/opt/alt/php-fpm53/usr/bin/php-config" ];then
cd /usr/local/src
rm -rf xcache-*
wget http://static.cdn-cwp.com/files/php/addons/xcache-3.2.0.tar.gz
tar xzf xcache-3.2.0.tar.gz
cd xcache-3.2.0
/opt/alt/php-fpm53/usr/bin/phpize
./configure --with-php-config=/opt/alt/php-fpm53/usr/bin/php-config
make && make install
echo ""

PHPEXTDIR=`/opt/alt/php-fpm53/usr/bin/php-config --extension-dir`

if [ -e "$PHPEXTDIR/xcache.so" ];then 
	echo "Creating config file"
	grep "xcache.so" /opt/alt/php-fpm53/usr/php/php.d/xcache.ini 2> /dev/null 1> /dev/null|| echo "extension=xcache.so" > /opt/alt/php-fpm53/usr/php/php.d/xcache.ini
else
	echo "ERROR: Missing extension file $PHPEXTDIR/xcache.so"
fi
else
echo "Skipping as php build failed"
fi
