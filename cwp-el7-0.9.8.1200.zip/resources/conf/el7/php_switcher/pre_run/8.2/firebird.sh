#/bin/bash

yum --enablerepo=epel -y install firebird firebird-devel