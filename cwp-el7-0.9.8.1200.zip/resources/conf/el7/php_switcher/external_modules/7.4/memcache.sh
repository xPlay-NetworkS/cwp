#!/bin/bash

yum -y install memcached
systemctl enable memcached
systemctl restart memcached
cd /usr/local/src
rm -rf memcache*
curl https://pecl.php.net/get/memcache-4.0.5.2.tgz -o memcache.tgz
tar -xf memcache.tgz
cd memcache-*/
phpize
./configure
make
make install
sed -i '/\<extension=memcache.so\>/d' /usr/local/php/php.ini
echo "extension=memcache.so" > /usr/local/php/php.d/memcache.ini
