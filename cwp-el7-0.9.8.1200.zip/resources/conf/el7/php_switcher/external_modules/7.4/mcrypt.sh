#!/bin/bash

cd /usr/local/src
rm -rf mcrypt*
wget http://static.cdn-cwp.com/files/php/pecl/mcrypt-1.0.1.tgz
tar -xf mcrypt-*
cd mcrypt-*/
phpize
./configure
make
make install
touch /usr/local/php/php.d/mcrypt.ini
echo "extension=mcrypt.so" > /usr/local/php/php.d/mcrypt.ini
