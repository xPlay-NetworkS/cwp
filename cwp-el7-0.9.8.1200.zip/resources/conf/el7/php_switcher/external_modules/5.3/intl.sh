#!/bin/bash

cd /usr/local/src
rm -rf intl-3.0.0.tgz
rm -rf intl-3.0.0
wget http://static.cdn-cwp.com/files/php/pecl/intl-3.0.0.tgz
tar -zxvf intl-3.0.0.tgz
cd intl-3.0.0
phpize
./configure
make
make install
echo "extension=intl.so" > /usr/local/php/php.d/intl.ini