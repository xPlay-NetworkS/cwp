yum -y install ImageMagick ImageMagick-devel ImageMagick-perl
cd /usr/local/src
rm -Rf imagick-3.4.3
rm -Rf imagick-3.1.2
rm -Rf imagick-3.4.3.tgz
rm -Rf imagick-3.1.2.tgz
wget http://static.cdn-cwp.com/files/php/pecl/imagick-3.1.2.tgz
tar zxf imagick-3.1.2.tgz
cd imagick-3.1.2
phpize
ln -s /usr/local/include/ImageMagick-6 /usr/local/include/ImageMagick
./configure
make clean
make
make install
echo ""
echo "extension=imagick.so" > /usr/local/php/php.d/imagick.ini
