#!/bin/bash

cd /usr/local/src
rm -rf /usr/local/zend/5.6
mkdir /usr/local/zend
mkdir /usr/local/zend/5.6
rm -rf zend-loader-php5.6-linux-x86_64
wget http://dl1.centos-webpanel.com/files/php/addons/zend-loader-php5.6-linux-x86_64.zip
unzip zend-loader-php5.6-linux-x86_64.zip
cd zend-loader-php5.6-linux-x86_64
yes | cp -rv * /usr/local/zend/5.6
echo "zend_extension=/usr/local/zend/5.6/ZendGuardLoader.so" > /usr/local/php/php.d/zend.ini