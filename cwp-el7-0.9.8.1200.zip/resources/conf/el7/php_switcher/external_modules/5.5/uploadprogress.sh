#!/bin/bash

cd /usr/local/src
rm -rf uploadprogress-1.0.3.1.tgz
wget http://static.cdn-cwp.com/files/php/pecl/uploadprogress-1.0.3.1.tgz
tar -zxvf uploadprogress-1.0.3.1.tgz
cd uploadprogress-1.0.3.1
phpize
./configure
make
make install
sed --in-place '/extension_dir=/d' /usr/local/php/php.ini
echo "extension=uploadprogress.so" > /usr/local/php/php.d/uploadprogress.ini