#!/bin/bash

cd /usr/local/src
rm -rf mailparse*
wget http://static.cdn-cwp.com/files/php/pecl/mailparse-2.1.6.tgz -O mailparse.tgz
tar zxf mailparse.tgz
cd mailparse-*/
phpize
./configure
make
make && make install
sed --in-place '/extension_dir=/d' /usr/local/php/php.ini
echo "extension=mailparse.so" > /usr/local/php/php.d/mailparse.ini


