#!/bin/bash

cd /usr/local/src
rm -rf mailparse*
curl https://pecl.php.net/get/mailparse -o mailparse.tgz
tar zxf mailparse.tgz
cd mailparse-*/
phpize
./configure
make
make && make install
sed --in-place '/extension_dir=/d' /usr/local/php/php.ini
echo "extension=mailparse.so" > /usr/local/php/php.d/mailparse.ini
