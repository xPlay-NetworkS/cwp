#!/bin/bash

cd /usr/local/src
wget https://launchpad.net/libmemcached/1.0/1.0.18/+download/libmemcached-1.0.18.tar.gz
tar -zxvf libmemcached-1.0.18.tar.gz
cd libmemcached-1.0.18
./configure
make && make install
yum -y install memcached
systemctl enable memcached
systemctl restart memcached
cd /usr/local/src
rm -rf memcached*
curl https://pecl.php.net/get/memcached -o memcached.tgz
tar -xf memcached.tgz
cd memcached-*/
phpize
./configure
make
make install
sed -i '/\<extension=memcached.so\>/d' /usr/local/php/php.ini
echo "extension=memcached.so" > /usr/local/php/php.d/memcached.ini
