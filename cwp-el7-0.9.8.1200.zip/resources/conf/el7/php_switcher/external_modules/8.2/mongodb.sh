#!/bin/bash

cd /usr/local/src
yum -y install openssl-devel
rm -rf mongodb*
wget http://static.cdn-cwp.com/files/php/pecl/mongodb-1.11.1.tgz
tar -zxvf mongodb-1.11.1.tgz
cd mongodb-1.11.1
phpize
./configure
make
make install
echo "extension=mongodb.so" > /usr/local/php/php.d/mongodb.ini