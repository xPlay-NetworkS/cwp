#!/bin/bash

yum --enablerepo=epel -y install libsodium libsodium-devel
cd /usr/local/src
rm -rf libsodium*
curl https://pecl.php.net/get/libsodium -o libsodium.tgz
tar zxf libsodium.tgz
cd libsodium-*/
phpize
./configure
make
make install
echo ""
echo "extension=sodium.so" > /usr/local/php/php.d/sodium.ini
