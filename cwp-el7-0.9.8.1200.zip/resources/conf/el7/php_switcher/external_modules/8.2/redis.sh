#!/bin/bash

cd /usr/local/src
yum -y remove remi-release
yum -y install epel-release
rpm -Uvh http://rpms.famillecollet.com/enterprise/remi-release-7.rpm
yum -y --enablerepo=remi,remi install redis
systemctl start redis
systemctl enable redis
rm -rf redis-*
rm -rf redis*
curl https://pecl.php.net/get/redis -o redis.tgz
tar -xf redis.tgz
cd redis-*/
phpize
./configure
make && make install
echo ""
echo "extension=redis.so" > /usr/local/php/php.d/redis.ini
