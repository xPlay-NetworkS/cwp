#!/bin/bash

cd /usr/local/src
rm -rf phar-2.0.0.tgz
rm -rf phar-2.0.0
wget http://static.cdn-cwp.com/files/php/pecl/phar-2.0.0.tgz
tar -zxvf phar-2.0.0.tgz
cd phar-2.0.0
phpize
./configure
make
make install
echo "extension=phar.so" > /usr/local/php/php.d/phar.ini