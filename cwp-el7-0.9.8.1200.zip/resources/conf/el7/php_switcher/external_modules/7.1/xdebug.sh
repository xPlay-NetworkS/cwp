#!/bin/bash

cd /usr/local/src
rm -rf xdebug*
wget http://static.cdn-cwp.com/files/php/pecl/xdebug.tgz
tar zxf xdebug.tgz
cd xdebug-*/
phpize
./configure
make
make && make install
echo "zend_extension=xdebug.so" > /usr/local/php/php.d/xdebug.ini

