#!/bin/bash

IONCUBEVER="8.0"

rm -rf /usr/local/php/php.d/ioncube.ini
touch /usr/local/php/php.d/ioncube.ini
sed -i '/ioncube_loader_lin/d' /usr/local/php/php.ini

if [ -e "/usr/local/ioncube/ioncube_loader_lin_$IONCUBEVER.so" ];then
        echo "zend_extension=/usr/local/ioncube/ioncube_loader_lin_$IONCUBEVER.so" > /usr/local/php/php.d/ioncube.ini
else
        sh /scripts/update_ioncube
        if [ -e "/usr/local/ioncube/ioncube_loader_lin_$IONCUBEVER.so" ];then
                echo "zend_extension=/usr/local/ioncube/ioncube_loader_lin_$IONCUBEVER.so" > /usr/local/php/php.d/ioncube.ini
        fi
fi
